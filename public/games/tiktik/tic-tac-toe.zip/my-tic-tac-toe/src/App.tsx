import React from 'react';
// import './App.css';
import TicTacToe from './TicTacToe';

const App: React.FC = () => {
  return (
    <div > 
      <TicTacToe />
    </div>
  );
}

export default App;
