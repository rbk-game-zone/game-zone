import React from 'react';
import MemoryGame from './MemoryGame';

function App() {
  return (
    <div className="min-h-screen">
      <MemoryGame />
    </div>
  );
}

export default App;