export const isDev = process.env.NEXT_PUBLIC_CHEATS === `true`
