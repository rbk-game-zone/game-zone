export const SIGNAL_OFFER = 'signalOffer'
export const SIGNAL_ANSWER = 'signalAnswer'
export const SIGNAL_ICE_CANDIDATE = 'signalIceCandidate'
